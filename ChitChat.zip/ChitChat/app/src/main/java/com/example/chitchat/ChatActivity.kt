package com.example.chitchat

import android.app.Dialog
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.Message
import android.widget.Toast
import com.bumptech.glide.Glide
import com.example.chitchat.adapter.MessageAdapter
import com.example.chitchat.databinding.ActivityChatBinding
import com.google.android.gms.auth.api.signin.internal.Storage
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener
import com.google.firebase.database.ktx.getValue
import com.google.firebase.ktx.Firebase
import com.google.firebase.storage.StorageReference
import java.util.Date

class ChatActivity : AppCompatActivity() {

    //binding ko declare kiya hai iss ma
    lateinit var binding: ActivityChatBinding

    //ab message ko firebase ma store kara ga isliya varible banya ga instance(database)
    lateinit var database: FirebaseDatabase


    //message jo send kar rha hai uski userid stroe karni hai isliya variable banya ga
    lateinit var senderUId:String

    //ab jo message receive kar rha hai uska variable banya ga
    lateinit var receiverUId:String

    //ab kya kara ga dono sender or receiver ko merge kar daga ek variable mai jiss sa ek variable ma store ho jaya
    lateinit var SenderRoom:String
    lateinit var ReceiverRoom:String

    //list define kara ga
    lateinit var list:ArrayList<MessageModel>




    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        //binding ko assign kiya hai issma
        binding= ActivityChatBinding.inflate(layoutInflater)
        setContentView(binding.root)

        //sender ki UID receive kara ga
        senderUId=FirebaseAuth.getInstance().uid.toString()
        //receiver ki UID ko receive kara ga
        receiverUId=intent.getStringExtra("uid")!!


        //list ko intialize kardiya hai
        list=ArrayList()

        //iss ma dono sender and receiver ko message dekha isliya ya likha hai
        SenderRoom=senderUId+receiverUId

        ReceiverRoom=receiverUId+senderUId



        //database wala variable ko initialize kara ga
        database= FirebaseDatabase.getInstance()



        //ya ham action perform kara ga ki send button pa click hoga toh kaya karna hai

        binding.sendMessage.setOnClickListener {

            //ab check kara ga user na koi message likha hai ya nai
            if(binding.MessageBox.text.isEmpty()){
                //empty hai toh toast dekha daga

                Toast.makeText(this,"Pleas Write Your Message",Toast.LENGTH_SHORT).show()
            }else{

                //agar message likha hai messageBox ma toh usko Firebase Database Ma Store Kar aga


                //iss ma kya ho rha hai messagemodel data class ma data bhej rha hai
                val message=MessageModel(binding.MessageBox.text.toString(),senderUId,Date().time)

                //iss ma ham kya kara ga randomkey generate kar ka waha message ko store kardaga
                val randomKey=database.reference.push().key

                //ab ham database ma node banaya ga jaha sari chats store hogi
                database.reference.child("Chats")
                    .child(SenderRoom).child("message").child(randomKey!!).setValue(message).addOnSuccessListener {

                        //jab sender ka room ma data store ho jaya ga tab ham receiver ka room ma data ko store kara ga

                        database.reference.child("Chats")
                            .child(ReceiverRoom).child("message").child(randomKey!!).setValue(message).addOnSuccessListener {

                                //message jab send ho jaya ga toh messagebox ko null kar daga
                                binding.MessageBox.text=null

                                Toast.makeText(this,"Message Send",Toast.LENGTH_SHORT).show()
                        }
                    }

            }
        }

        //message show hoga recyclerview ma

        database.reference.child("Chats").child(SenderRoom).child("message")
            .addValueEventListener(object :ValueEventListener{
                override fun onDataChange(snapshot: DataSnapshot) {
                    list.clear()

                    for(snapshot1 in snapshot.children){
                        val data=snapshot1.getValue(MessageModel::class.java)
                        list.add(data!!)
                    }
                    binding.recyclerView.adapter=MessageAdapter(this@ChatActivity,list)
                }

                override fun onCancelled(error: DatabaseError) {
                    Toast.makeText(this@ChatActivity,"Error is $error",Toast.LENGTH_SHORT).show()
                }
            })














    }

}